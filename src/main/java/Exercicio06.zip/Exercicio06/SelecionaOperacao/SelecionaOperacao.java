package Exercicio06.SelecionaOperacao;

import Exercicio06.Modelo.*;

public interface SelecionaOperacao {
    
    public Numero seleciona(Operador operador, Numero numA, Numero numB);
    
}
