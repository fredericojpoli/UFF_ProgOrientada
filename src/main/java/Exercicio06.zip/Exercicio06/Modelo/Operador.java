package Exercicio06.Modelo;

public class Operador extends Particula {
            
    public Operador(String nome) {
        super(nome);
    }
    
    
    
}
