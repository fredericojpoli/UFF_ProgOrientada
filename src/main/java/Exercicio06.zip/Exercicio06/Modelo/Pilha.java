package Exercicio06.Modelo;

public class Pilha {
    public Particula info;
    public Pilha proximo = null;
}
