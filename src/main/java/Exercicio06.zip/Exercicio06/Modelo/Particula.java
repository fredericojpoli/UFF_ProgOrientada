package Exercicio06.Modelo;

public class Particula {
    
    private String nome;
    
    public Particula(String nome) {
        this.nome = nome;
    }
    
    public String getNome() {
        return nome;
    }
}