package Exercicio06.Modelo;

public class Operacao {
    public Numero fatorA;
    public Numero fatorB;
    
    public Operacao(Numero A, Numero B) {
        fatorA = A;
        fatorB = B;
    }
}
